# online_blood_bank
Our aim is to make that particular kind of blood  available to the hospital who needs it in a very moment by sending emails to all the donors around the hospital in a 10km radius through our online website.
 
                                                           Objective
The main objective was to create a unique and useful “ Online Blood Donation Website ” with exceptional quality and service that differentiates it from other online system.

                                                           Introduction
A blood bank is present mostly in every hospital but sometimes there come situations where blood  bank doesn’t have that particular blood group which are required by the patient So, for that, we have made a Portal where hospitals who are being registered already can log in and ask for that particular kind of blood to the people who have registered on that portal  So as soon as they make a request then within a radius of 10 km that hospital every person who has registered on that portal will receive an email for donating that particular group of blood to the hospital By this portal, our mission is to serve our community by meeting the needs of patients, hospitals, and members for safe, high-quality blood products and related services.

                                                              Scope
The scope of our Online Blood Donation Website is as follows:

The website can be used globally by connecting hospitals everywhere around the world so that the hospital can contact donors and blood could be easily available .
In case of emergency it makes it easy for the donor to donate the blood and saves someone's life .
In future by this email system the donors could be alerted about the nearby blood camp.
Right now the donors are alerted through emails in future we can think of alerting them by SMS.

                                                          Existing System
There is a government website it just provide the data of the total blood present defects but do not provide a personality through which someone can request the blood.

                                                          Proposed System
Here we want to design an online website through which all donors around the hospital within a radius of 10 kilometres can be alerted through email system for donating the blood in case of emergency or generally through this system the blood required by the hospital and the donors blood with that same blood group are only been alerted
User can register themselves on the website by providing the information of the blood group. So whenever the blood matches with the requirement of the hospital that particular user if in the radius of 10 kms of the hospital gets an email through our system . Email is only sent when the hospital login on our website and click on the button of request.
