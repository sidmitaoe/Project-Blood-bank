<style>
    #error
    {
        height: 80%;
        width: 100%;
        text-align: center;
        font-family: 'Times New Roman', Times, serif;
        color: grey;

    }
    #error-content
    {
        top: 40%;
        left: 28%;
        position: absolute;
    }
</style>

<div id='error'>
    <div id='error-content'>
        <h2>Error Page 404 NOT FOUND </h2>
        <h4>Either you don't have Authorization to access the page or the page does not exist</h4>
        <h5>Sorry for inconvenience caused</h5>
    </div>    
</div>