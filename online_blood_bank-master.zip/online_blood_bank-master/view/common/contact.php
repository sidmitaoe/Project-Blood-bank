<head>
    <link rel="stylesheet" type="text/css" href="css/contact_us_file.css"/>
</head>
<div id='contact-us'>
    <div id='left-section-contact-us'>
        <h2>Our Address</h2>
        MIT Academy Of Engineering    
        <p>
        
        Dehu Phata, Alandi (D),
        <br>Pune, 
        <br>Maharashtra - 412105
        <br>India
        
        </p>
    </div>
    <div id='right-section-contact-us'>
    
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3779.752900618629!2d73.890554114371!3d18.67508116930573!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c880511d7c35%3A0xc4e495a8c1f663eb!2sMIT%20Academy%20of%20Engineering!5e0!3m2!1sen!2sin!4v1574162258059!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>    
    </div>
</div>        