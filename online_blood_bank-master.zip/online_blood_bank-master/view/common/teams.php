<head>
	<link rel="stylesheet" type="text/css" href="css/teams_file.css">
</head>
<div id='teams'>
    <h1 style='text-align: center; color: crimson;'> Our Team</h1>
    <div class="row_1">
        <div class="col_1">
            <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                <img src="img/sachin_sahil.jpg" alt="Avatar" style="width:300px;height:300px;">
                </div>
                <div class="flip-card-back">
                <h1>Sachin Sahil</h1>
                <p>Front-end Developer, Back end Developer and Content Writer</p>
                <p>He worked on the database design , logical flow of the website , front-end developement of the
                    website as well as idea of the website.
                </p>
                </div>
            </div>
            </div>
        </div>
        <div class="col_1">    
            <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                <img src="img/Sid_jain.jpeg" alt="Avatar" style="height:300px;">
                </div>
                <div class="flip-card-back">
                <h1>Siddhant Jain</h1>
                <p>Front-end Developer and  Documentation</p>
                <p>he worked on the front-end , as well wrote content to be seen by user.</p>
                </div>
            </div>
            </div>
        </div>    
    </div>
    <div class="row_1">
        <div class="col_1">
            <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                <img src="img/shubham_nehru.jpg" alt="Avatar" style="width:300px;height:300px;">
                </div>
                <div class="flip-card-back">
                <h1>Shubham Nehru</h1>
                <p>Front-end Developer</p>
                <p>He worked on the front-end of the website</p>
                </div>
            </div>
            </div>
        </div>   
        <div class="col_1">
            <div class="flip-card">
            <div class="flip-card-inner">
                <div class="flip-card-front">
                <img src="img/sachin_gadage.jpeg" alt="Avatar" style="width:300px;height:300px;">
                </div>
                <div class="flip-card-back">
                <h1>Sachin Gadage</h1>
                <p>Front-end Developer</p>
                <p>He worked on the front-end of the website.</p>
                </div>
            </div>
            </div>
        </div>
    </div>        
</div>